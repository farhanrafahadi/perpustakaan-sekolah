<x-admin-layout title="Dashboard">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-body">
                    You're logged in!
                </div>
            </div>
        </div>
    </div>
</x-admin-layout>
